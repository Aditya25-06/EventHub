package com.eventhub.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/** Hibernate entity mapped to the "registrations" table. */
@Entity
@Table(name = "registrations")
public class Registration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reg_id")
    private Integer regId;

    @Column(name = "user_id", nullable = false)
    private int userId;

    @Column(name = "event_id", nullable = false)
    private int eventId;

    public Registration() { }

    public Registration(int userId, int eventId) {
        this.userId = userId;
        this.eventId = eventId;
    }

    public Integer getRegId() { return regId; }
    public void setRegId(Integer regId) { this.regId = regId; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public int getEventId() { return eventId; }
    public void setEventId(int eventId) { this.eventId = eventId; }
}
