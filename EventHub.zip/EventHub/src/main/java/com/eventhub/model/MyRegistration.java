package com.eventhub.model;

/** Read-only view bean used on the "My Registrations" page. */
public class MyRegistration {
    private final int regId;
    private final int eventId;
    private final String title;
    private final String venue;
    private final String eventDate;
    private final String regDate;

    public MyRegistration(int regId, int eventId, String title, String venue, String eventDate, String regDate) {
        this.regId = regId;
        this.eventId = eventId;
        this.title = title;
        this.venue = venue;
        this.eventDate = eventDate;
        this.regDate = regDate;
    }

    public int getRegId() { return regId; }
    public int getEventId() { return eventId; }
    public String getTitle() { return title; }
    public String getVenue() { return venue; }
    public String getEventDate() { return eventDate; }
    public String getRegDate() { return regDate; }
}
