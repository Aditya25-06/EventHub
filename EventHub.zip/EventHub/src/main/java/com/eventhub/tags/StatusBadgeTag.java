package com.eventhub.tags;

import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.SimpleTagSupport;
import java.io.IOException;

/** Custom tag: &lt;eh:statusBadge seats="5" total="40"/&gt; prints an Open / Few left / Full badge. */
public class StatusBadgeTag extends SimpleTagSupport {

    private int seats;
    private int total;

    public void setSeats(int seats) { this.seats = seats; }
    public void setTotal(int total) { this.total = total; }

    @Override
    public void doTag() throws JspException, IOException {
        String css;
        String text;
        if (seats <= 0) {
            css = "badge-full";
            text = "Full";
        } else if (total > 0 && seats * 100 / total <= 20) {
            css = "badge-low";
            text = "Few left";
        } else {
            css = "badge-open";
            text = "Open";
        }
        getJspContext().getOut().print("<span class=\"badge " + css + "\">" + text + "</span>");
    }
}
