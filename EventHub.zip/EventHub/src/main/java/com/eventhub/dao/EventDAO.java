package com.eventhub.dao;

import com.eventhub.model.Event;
import com.eventhub.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/** JDBC CRUD operations for the events table. */
public class EventDAO {

    private Event map(ResultSet rs) throws SQLException {
        Event e = new Event();
        e.setEventId(rs.getInt("event_id"));
        e.setTitle(rs.getString("title"));
        e.setDescription(rs.getString("description"));
        e.setVenue(rs.getString("venue"));
        e.setEventDate(rs.getDate("event_date"));
        e.setTotalSeats(rs.getInt("total_seats"));
        e.setAvailableSeats(rs.getInt("available_seats"));
        return e;
    }

    // READ (all)
    public List<Event> getAll() {
        List<Event> list = new ArrayList<>();
        String sql = "SELECT * FROM events ORDER BY event_date, event_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return list;
    }

    // READ (one)
    public Event getById(int id) {
        String sql = "SELECT * FROM events WHERE event_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    // CREATE
    public boolean insert(Event e) {
        String sql = "INSERT INTO events (title, description, venue, event_date, total_seats, available_seats) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getTitle());
            ps.setString(2, e.getDescription());
            ps.setString(3, e.getVenue());
            ps.setDate(4, e.getEventDate());
            ps.setInt(5, e.getTotalSeats());
            ps.setInt(6, e.getTotalSeats());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    // UPDATE (keeps available seats consistent when total seats change)
    public boolean update(Event e) {
        String sql = "UPDATE events SET title = ?, description = ?, venue = ?, event_date = ?, "
                + "available_seats = GREATEST(available_seats + (? - total_seats), 0), total_seats = ? "
                + "WHERE event_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, e.getTitle());
            ps.setString(2, e.getDescription());
            ps.setString(3, e.getVenue());
            ps.setDate(4, e.getEventDate());
            ps.setInt(5, e.getTotalSeats());
            ps.setInt(6, e.getTotalSeats());
            ps.setInt(7, e.getEventId());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    // DELETE
    public boolean delete(int id) {
        String sql = "DELETE FROM events WHERE event_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    /** Uses a plain Statement (fixed query, no user input) for dashboard counts. */
    public int count(String table) {
        if (!List.of("users", "events", "registrations").contains(table)) {
            return 0;
        }
        String sql = "SELECT COUNT(*) FROM " + table;
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return 0;
    }
}
