package com.eventhub.dao;

import com.eventhub.model.MyRegistration;
import com.eventhub.model.Registration;
import com.eventhub.util.HibernateUtil;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.hibernate.Session;
import org.hibernate.Transaction;

/** Hibernate-based data access for registrations: insert, update, delete, select. */
public class RegistrationDAO {

    /** INSERT (+ seat UPDATE) in one transaction. Returns OK, DUP, FULL or ERROR. */
    public String register(int userId, int eventId) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();

            Long already = s.createQuery(
                    "select count(r) from Registration r where r.userId = :u and r.eventId = :e", Long.class)
                    .setParameter("u", userId)
                    .setParameter("e", eventId)
                    .uniqueResult();
            if (already != null && already > 0) {
                tx.rollback();
                return "DUP";
            }

            int rows = s.createNativeMutationQuery(
                    "UPDATE events SET available_seats = available_seats - 1 WHERE event_id = :e AND available_seats > 0")
                    .setParameter("e", eventId)
                    .executeUpdate();
            if (rows == 0) {
                tx.rollback();
                return "FULL";
            }

            s.persist(new Registration(userId, eventId));
            tx.commit();
            return "OK";
        } catch (Exception ex) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            ex.printStackTrace();
            return "ERROR";
        }
    }

    /** DELETE (+ seat UPDATE) in one transaction. */
    public boolean cancel(int regId, int userId) {
        Transaction tx = null;
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            tx = s.beginTransaction();
            Registration r = s.get(Registration.class, regId);
            if (r == null || r.getUserId() != userId) {
                tx.rollback();
                return false;
            }
            int eventId = r.getEventId();
            s.remove(r);
            s.createNativeMutationQuery(
                    "UPDATE events SET available_seats = available_seats + 1 WHERE event_id = :e")
                    .setParameter("e", eventId)
                    .executeUpdate();
            tx.commit();
            return true;
        } catch (Exception ex) {
            if (tx != null && tx.isActive()) {
                tx.rollback();
            }
            ex.printStackTrace();
            return false;
        }
    }

    /** SELECT using HQL: ids of the events a student has registered for. */
    public Set<Integer> registeredEventIds(int userId) {
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            List<Integer> ids = s.createQuery(
                    "select r.eventId from Registration r where r.userId = :u", Integer.class)
                    .setParameter("u", userId)
                    .list();
            return new HashSet<>(ids);
        } catch (Exception ex) {
            ex.printStackTrace();
            return new HashSet<>();
        }
    }

    /** SELECT using a native join to show event details with each registration. */
    public List<MyRegistration> getMyRegistrations(int userId) {
        List<MyRegistration> list = new ArrayList<>();
        String sql = "SELECT r.reg_id, e.event_id, e.title, e.venue, e.event_date, r.reg_date "
                + "FROM registrations r JOIN events e ON r.event_id = e.event_id "
                + "WHERE r.user_id = :u ORDER BY e.event_date";
        try (Session s = HibernateUtil.getSessionFactory().openSession()) {
            List<Object[]> rows = s.createNativeQuery(sql, Object[].class)
                    .setParameter("u", userId)
                    .list();
            for (Object[] o : rows) {
                list.add(new MyRegistration(
                        ((Number) o[0]).intValue(),
                        ((Number) o[1]).intValue(),
                        String.valueOf(o[2]),
                        String.valueOf(o[3]),
                        String.valueOf(o[4]),
                        String.valueOf(o[5])));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }
}
