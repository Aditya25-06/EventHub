package com.eventhub.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/** Builds the Hibernate SessionFactory once from hibernate.cfg.xml. */
public class HibernateUtil {

    private static SessionFactory factory;

    public static synchronized SessionFactory getSessionFactory() {
        if (factory == null) {
            factory = new Configuration().configure().buildSessionFactory();
        }
        return factory;
    }
}
