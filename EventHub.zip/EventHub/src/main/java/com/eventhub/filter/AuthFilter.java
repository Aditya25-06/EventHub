package com.eventhub.filter;

import com.eventhub.model.User;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/** Protects every page except login, sign-up and static files. Admin URLs need the ADMIN role. */
@WebFilter("/*")
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest rq = (HttpServletRequest) req;
        HttpServletResponse rs = (HttpServletResponse) res;
        String path = rq.getServletPath();

        boolean isPublic = path.equals("/") || path.equals("/index.html")
                || path.equals("/login") || path.equals("/login.jsp")
                || path.equals("/signup") || path.equals("/signup.jsp")
                || path.startsWith("/css/");

        HttpSession session = rq.getSession(false);
        User user = (session == null) ? null : (User) session.getAttribute("user");

        if (!isPublic && user == null) {
            rs.sendRedirect(rq.getContextPath() + "/login?msg=loginfirst");
            return;
        }
        if (path.startsWith("/admin/") && (user == null || !"ADMIN".equals(user.getRole()))) {
            rs.sendRedirect(rq.getContextPath() + "/dashboard?msg=denied");
            return;
        }
        chain.doFilter(req, res);
    }
}
