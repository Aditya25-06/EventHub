package com.eventhub.controller;

import com.eventhub.dao.RegistrationDAO;
import com.eventhub.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/my-registrations")
public class MyRegistrationsServlet extends HttpServlet {

    private final RegistrationDAO regDAO = new RegistrationDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        request.setAttribute("myRegs", regDAO.getMyRegistrations(user.getUserId()));
        request.getRequestDispatcher("/WEB-INF/views/my-registrations.jsp").forward(request, response);
    }
}
