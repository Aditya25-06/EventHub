package com.eventhub.controller;

import com.eventhub.dao.EventDAO;
import com.eventhub.util.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Participant report. Column names come from ResultSetMetaData, so the table builds itself. */
@WebServlet("/admin/report")
public class ReportServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int eventId = 0;
        try {
            eventId = Integer.parseInt(request.getParameter("eventId"));
        } catch (NumberFormatException | NullPointerException ignored) {
        }

        String sql = "SELECT r.reg_id AS Reg_No, u.name AS Student, u.email AS Email, "
                + "e.title AS Event, e.event_date AS Event_Date, r.reg_date AS Registered_On "
                + "FROM registrations r JOIN users u ON r.user_id = u.user_id "
                + "JOIN events e ON r.event_id = e.event_id "
                + (eventId > 0 ? "WHERE e.event_id = ? " : "")
                + "ORDER BY r.reg_id DESC";

        List<String> headers = new ArrayList<>();
        List<List<String>> rows = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            if (eventId > 0) {
                ps.setInt(1, eventId);
            }
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData md = rs.getMetaData();
                int cols = md.getColumnCount();
                for (int i = 1; i <= cols; i++) {
                    headers.add(md.getColumnLabel(i).replace('_', ' '));
                }
                while (rs.next()) {
                    List<String> row = new ArrayList<>();
                    for (int i = 1; i <= cols; i++) {
                        row.add(String.valueOf(rs.getObject(i)));
                    }
                    rows.add(row);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("headers", headers);
        request.setAttribute("rows", rows);
        request.setAttribute("selectedEvent", eventId);
        request.setAttribute("events", new EventDAO().getAll());
        request.getRequestDispatcher("/WEB-INF/views/report.jsp").forward(request, response);
    }
}
