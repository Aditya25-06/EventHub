package com.eventhub.controller;

import com.eventhub.dao.EventDAO;
import com.eventhub.dao.RegistrationDAO;
import com.eventhub.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** Retrieves events from the database and forwards them to events.jsp. */
@WebServlet("/events")
public class EventListServlet extends HttpServlet {

    private final EventDAO eventDAO = new EventDAO();
    private final RegistrationDAO regDAO = new RegistrationDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        request.setAttribute("events", eventDAO.getAll());
        if (!"ADMIN".equals(user.getRole())) {
            request.setAttribute("registeredIds", regDAO.registeredEventIds(user.getUserId()));
        }
        request.getRequestDispatcher("/WEB-INF/views/events.jsp").forward(request, response);
    }
}
