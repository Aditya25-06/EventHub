package com.eventhub.controller;

import com.eventhub.dao.EventDAO;
import com.eventhub.model.Event;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;

/**
 * Admin-only (protected by AuthFilter, URL under /admin/).
 * GET  ?action=new | edit&id=..  -> shows the form
 * POST action=save | delete       -> performs the JDBC operation, then redirects
 */
@WebServlet("/admin/event")
public class EventAdminServlet extends HttpServlet {

    private final EventDAO dao = new EventDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if ("edit".equals(request.getParameter("action"))) {
            Event e = dao.getById(toInt(request.getParameter("id")));
            if (e == null) {
                response.sendRedirect(request.getContextPath() + "/events?msg=error");
                return;
            }
            request.setAttribute("event", e);
        }
        request.getRequestDispatcher("/WEB-INF/views/event-form.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String ctx = request.getContextPath();
        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            boolean ok = dao.delete(toInt(request.getParameter("eventId")));
            response.sendRedirect(ctx + "/events?msg=" + (ok ? "deleted" : "error"));
            return;
        }

        try {
            Event e = new Event();
            e.setEventId(toInt(request.getParameter("eventId")));
            e.setTitle(request.getParameter("title").trim());
            e.setDescription(request.getParameter("description").trim());
            e.setVenue(request.getParameter("venue").trim());
            e.setEventDate(Date.valueOf(request.getParameter("eventDate")));
            e.setTotalSeats(Integer.parseInt(request.getParameter("totalSeats")));

            if (e.getTitle().isEmpty() || e.getTotalSeats() < 1) {
                response.sendRedirect(ctx + "/events?msg=error");
                return;
            }
            boolean ok = (e.getEventId() > 0) ? dao.update(e) : dao.insert(e);
            response.sendRedirect(ctx + "/events?msg=" + (ok ? "saved" : "error"));
        } catch (IllegalArgumentException | NullPointerException ex) {
            response.sendRedirect(ctx + "/events?msg=error");
        }
    }

    private int toInt(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException | NullPointerException e) {
            return 0;
        }
    }
}
