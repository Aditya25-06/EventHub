package com.eventhub.controller;

import com.eventhub.dao.UserDAO;
import com.eventhub.model.User;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Mapped in web.xml (with init-params read through ServletConfig).
 * Shows the servlet life cycle: init() -> service()/doGet()/doPost() -> destroy().
 */
public class LoginServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    public void init() throws ServletException {
        ServletConfig config = getServletConfig();
        String appName = config.getInitParameter("appName");
        String adminEmail = config.getInitParameter("adminEmail");
        getServletContext().setAttribute("appName", appName);
        getServletContext().setAttribute("adminEmail", adminEmail);
        log("LoginServlet: init() called - servlet loaded by the web container");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("user") != null) {
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return;
        }
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        email = (email == null) ? "" : email.trim();
        password = (password == null) ? "" : password;

        User user = userDAO.login(email, password);
        if (user == null) {
            request.setAttribute("error", "Email or password is incorrect. Check both and try again.");
            request.setAttribute("email", email);
            // forward: same request continues to the JSP
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        } else {
            HttpSession session = request.getSession(true);
            session.setAttribute("user", user);
            session.setMaxInactiveInterval(30 * 60);
            // redirect: browser makes a brand-new GET request (avoids re-submit on refresh)
            response.sendRedirect(request.getContextPath() + "/dashboard");
        }
    }

    @Override
    public void destroy() {
        log("LoginServlet: destroy() called - servlet is being unloaded");
    }
}
