package com.eventhub.controller;

import com.eventhub.dao.EventDAO;
import com.eventhub.dao.RegistrationDAO;
import com.eventhub.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    private final EventDAO eventDAO = new EventDAO();
    private final RegistrationDAO regDAO = new RegistrationDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        request.setAttribute("totalEvents", eventDAO.count("events"));

        if ("ADMIN".equals(user.getRole())) {
            request.setAttribute("totalRegs", eventDAO.count("registrations"));
            request.setAttribute("totalUsers", eventDAO.count("users"));
            request.getRequestDispatcher("/WEB-INF/views/admin-dashboard.jsp").forward(request, response);
        } else {
            request.setAttribute("myCount", regDAO.getMyRegistrations(user.getUserId()).size());
            request.getRequestDispatcher("/WEB-INF/views/student-dashboard.jsp").forward(request, response);
        }
    }
}
