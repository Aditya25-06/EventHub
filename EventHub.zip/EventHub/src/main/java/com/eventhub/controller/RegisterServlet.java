package com.eventhub.controller;

import com.eventhub.dao.RegistrationDAO;
import com.eventhub.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** POST /register with action=register (eventId) or action=cancel (regId). Uses Hibernate. */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private final RegistrationDAO regDAO = new RegistrationDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        String ctx = request.getContextPath();
        String action = request.getParameter("action");

        try {
            if ("register".equals(action)) {
                int eventId = Integer.parseInt(request.getParameter("eventId"));
                String result = regDAO.register(user.getUserId(), eventId);
                String msg;
                switch (result) {
                    case "OK":   msg = "registered"; break;
                    case "DUP":  msg = "dup"; break;
                    case "FULL": msg = "full"; break;
                    default:     msg = "error";
                }
                response.sendRedirect(ctx + "/events?msg=" + msg);
            } else if ("cancel".equals(action)) {
                int regId = Integer.parseInt(request.getParameter("regId"));
                boolean ok = regDAO.cancel(regId, user.getUserId());
                response.sendRedirect(ctx + "/my-registrations?msg=" + (ok ? "cancelled" : "error"));
            } else {
                response.sendRedirect(ctx + "/events?msg=error");
            }
        } catch (NumberFormatException ex) {
            response.sendRedirect(ctx + "/events?msg=error");
        }
    }
}
