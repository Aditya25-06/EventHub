package com.eventhub.controller;

import com.eventhub.dao.UserDAO;
import com.eventhub.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/signup")
public class SignupServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/signup.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = trim(request.getParameter("name"));
        String email = trim(request.getParameter("email"));
        String password = request.getParameter("password");
        String confirm = request.getParameter("confirm");

        String error = null;
        if (name.isEmpty() || email.isEmpty() || password == null || password.length() < 6) {
            error = "Fill in every field. Your password needs at least 6 characters.";
        } else if (!password.equals(confirm)) {
            error = "The two passwords do not match.";
        } else if (userDAO.emailExists(email)) {
            error = "This email is already registered. Log in instead.";
        }

        if (error != null) {
            request.setAttribute("error", error);
            request.setAttribute("name", name);
            request.setAttribute("email", email);
            request.getRequestDispatcher("/signup.jsp").forward(request, response);
            return;
        }

        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setPassword(password);
        boolean ok = userDAO.register(u);
        response.sendRedirect(request.getContextPath() + (ok ? "/login?msg=signedup" : "/signup"));
    }

    private String trim(String s) {
        return s == null ? "" : s.trim();
    }
}
