<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Sign up" scope="request"/>
<%@ include file="/WEB-INF/views/includes/header.jsp" %>

<div class="form-card">
  <h2>Create your student account</h2>
  <c:if test="${not empty error}"><div class="alert alert-err"><c:out value="${error}"/></div></c:if>
  <form method="post" action="${ctx}/signup">
    <label for="name">Full name</label>
    <input type="text" id="name" name="name" value="<c:out value='${name}'/>" required autofocus>
    <label for="email">Email</label>
    <input type="email" id="email" name="email" value="<c:out value='${email}'/>" required>
    <div class="form-row">
      <div><label for="password">Password</label><input type="password" id="password" name="password" minlength="6" required></div>
      <div><label for="confirm">Confirm password</label><input type="password" id="confirm" name="confirm" minlength="6" required></div>
    </div>
    <button type="submit" class="btn btn-primary">Create account</button>
  </form>
  <p class="form-foot">Already registered? <a href="${ctx}/login">Log in</a></p>
</div>

<%@ include file="/WEB-INF/views/includes/footer.jsp" %>
