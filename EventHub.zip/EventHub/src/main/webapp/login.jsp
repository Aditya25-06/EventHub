<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Log in" scope="request"/>
<%@ include file="/WEB-INF/views/includes/header.jsp" %>

<div class="form-card">
  <h2>Welcome back</h2>
  <c:if test="${not empty error}"><div class="alert alert-err"><c:out value="${error}"/></div></c:if>
  <form method="post" action="${ctx}/login">
    <label for="email">Email</label>
    <input type="email" id="email" name="email" value="<c:out value='${email}'/>" required autofocus>
    <label for="password">Password</label>
    <input type="password" id="password" name="password" required>
    <button type="submit" class="btn btn-primary">Log in</button>
  </form>
  <p class="form-foot">New here? <a href="${ctx}/signup">Create an account</a></p>
</div>

<%@ include file="/WEB-INF/views/includes/footer.jsp" %>
