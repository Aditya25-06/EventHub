<%-- jsp:forward action demo: /home.jsp sends the request on to the dashboard servlet --%>
<jsp:forward page="/dashboard"/>
