<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="My registrations" scope="request"/>
<%@ include file="/WEB-INF/views/includes/header.jsp" %>

<h1 class="page-title">My registrations</h1>
<p class="page-sub">Cancel a registration to give your seat to someone else.</p>

<c:choose>
  <c:when test="${empty myRegs}">
    <div class="empty">You have not registered for any event yet.<br><br>
      <a class="btn btn-primary" href="${ctx}/events">Browse events</a></div>
  </c:when>
  <c:otherwise>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Event</th><th>Venue</th><th>Event date</th><th>Registered on</th><th></th></tr></thead>
        <tbody>
          <c:forEach var="r" items="${myRegs}">
            <tr>
              <td><strong><c:out value="${r.title}"/></strong></td>
              <td><c:out value="${r.venue}"/></td>
              <td><c:out value="${r.eventDate}"/></td>
              <td><c:out value="${r.regDate}"/></td>
              <td>
                <form method="post" action="${ctx}/register" onsubmit="return confirm('Cancel this registration?');">
                  <input type="hidden" name="action" value="cancel">
                  <input type="hidden" name="regId" value="${r.regId}">
                  <button type="submit" class="btn btn-sm btn-danger">Cancel</button>
                </form>
              </td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </div>
  </c:otherwise>
</c:choose>

<%@ include file="/WEB-INF/views/includes/footer.jsp" %>
