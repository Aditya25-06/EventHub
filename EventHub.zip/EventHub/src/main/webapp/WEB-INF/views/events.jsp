<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="eh" uri="http://eventhub.com/tags" %>
<c:set var="pageTitle" value="Events" scope="request"/>
<%@ include file="/WEB-INF/views/includes/header.jsp" %>

<h1 class="page-title">Upcoming events</h1>
<p class="page-sub">
  <c:choose>
    <c:when test="${sessionScope.user.role == 'ADMIN'}">Edit or remove events, or add a new one.</c:when>
    <c:otherwise>Pick an event and register. Seats are limited.</c:otherwise>
  </c:choose>
</p>

<c:if test="${sessionScope.user.role == 'ADMIN'}">
  <p style="margin-bottom:22px"><a class="btn btn-primary" href="${ctx}/admin/event?action=new">Add event</a></p>
</c:if>

<c:choose>
  <c:when test="${empty events}">
    <div class="empty">No events yet. Check back soon.</div>
  </c:when>
  <c:otherwise>
    <div class="grid">
      <c:forEach var="e" items="${events}">
        <article class="ticket">
          <div class="ticket-top">
            <span class="ticket-date"><c:out value="${e.eventDate}"/></span>
            <h3><c:out value="${e.title}"/></h3>
            <p class="venue">Venue: <c:out value="${e.venue}"/></p>
            <p class="desc"><c:out value="${e.description}"/></p>
          </div>
          <div class="ticket-tear"></div>
          <div class="ticket-bottom">
            <div class="seats">
              <eh:statusBadge seats="${e.availableSeats}" total="${e.totalSeats}"/>
              <span>${e.availableSeats} of ${e.totalSeats} seats left</span>
            </div>
            <div class="actions">
              <c:choose>
                <c:when test="${sessionScope.user.role == 'ADMIN'}">
                  <a class="btn btn-sm" href="${ctx}/admin/event?action=edit&id=${e.eventId}">Edit</a>
                  <form method="post" action="${ctx}/admin/event" onsubmit="return confirm('Delete this event and all its registrations?');">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="eventId" value="${e.eventId}">
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                  </form>
                </c:when>
                <c:when test="${registeredIds.contains(e.eventId)}">
                  <span class="badge badge-open">You are registered</span>
                </c:when>
                <c:when test="${e.availableSeats <= 0}">
                  <button class="btn btn-sm" disabled>Full</button>
                </c:when>
                <c:otherwise>
                  <form method="post" action="${ctx}/register">
                    <input type="hidden" name="action" value="register">
                    <input type="hidden" name="eventId" value="${e.eventId}">
                    <button type="submit" class="btn btn-sm btn-primary">Register</button>
                  </form>
                </c:otherwise>
              </c:choose>
            </div>
          </div>
        </article>
      </c:forEach>
    </div>
  </c:otherwise>
</c:choose>

<%@ include file="/WEB-INF/views/includes/footer.jsp" %>
