<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="Admin dashboard" scope="request"/>
<%@ include file="/WEB-INF/views/includes/header.jsp" %>

<%-- jsp:useBean action creates a java.util.Date object --%>
<jsp:useBean id="today" class="java.util.Date"/>

<h1 class="page-title">Admin dashboard</h1>
<p class="page-sub"><fmt:formatDate value="${today}" pattern="EEEE, dd MMMM yyyy"/>. Manage events and see who is coming.</p>

<div class="stats">
  <div class="stat"><div class="num">${totalEvents}</div><div class="lbl">Events listed</div></div>
  <div class="stat"><div class="num">${totalRegs}</div><div class="lbl">Registrations</div></div>
  <div class="stat"><div class="num">${totalUsers}</div><div class="lbl">Users</div></div>
</div>

<div class="quick">
  <a class="btn btn-primary" href="${ctx}/admin/event?action=new">Add a new event</a>
  <a class="btn" href="${ctx}/events">Manage events</a>
  <a class="btn" href="${ctx}/admin/report">View participants</a>
</div>

<%@ include file="/WEB-INF/views/includes/footer.jsp" %>
