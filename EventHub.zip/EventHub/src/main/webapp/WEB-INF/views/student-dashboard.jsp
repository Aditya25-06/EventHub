<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="pageTitle" value="My dashboard" scope="request"/>
<%@ include file="/WEB-INF/views/includes/header.jsp" %>

<jsp:useBean id="today" class="java.util.Date"/>
<%
    int hour = java.time.LocalTime.now().getHour();
    String greeting = (hour < 12) ? "Good morning" : (hour < 17) ? "Good afternoon" : "Good evening";
%>

<h1 class="page-title"><%= greeting %>, <c:out value="${sessionScope.user.name}"/></h1>
<p class="page-sub"><fmt:formatDate value="${today}" pattern="EEEE, dd MMMM yyyy"/>. Find an event and book your seat.</p>

<div class="stats">
  <div class="stat"><div class="num">${totalEvents}</div><div class="lbl">Events to explore</div></div>
  <div class="stat"><div class="num">${myCount}</div><div class="lbl">Your registrations</div></div>
</div>

<div class="quick">
  <a class="btn btn-primary" href="${ctx}/events">Browse events</a>
  <a class="btn" href="${ctx}/my-registrations">My registrations</a>
</div>

<%@ include file="/WEB-INF/views/includes/footer.jsp" %>
