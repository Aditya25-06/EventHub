<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="isEdit" value="${not empty event}"/>
<c:set var="pageTitle" value="${isEdit ? 'Edit event' : 'Add event'}" scope="request"/>
<%@ include file="/WEB-INF/views/includes/header.jsp" %>

<div class="form-card wide">
  <h2><c:out value="${pageTitle}"/></h2>
  <form method="post" action="${ctx}/admin/event">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="eventId" value="${isEdit ? event.eventId : 0}">

    <label for="title">Event title</label>
    <input type="text" id="title" name="title" maxlength="100" value="<c:out value='${event.title}'/>" required autofocus>

    <label for="description">Description</label>
    <textarea id="description" name="description" rows="4"><c:out value="${event.description}"/></textarea>

    <label for="venue">Venue</label>
    <input type="text" id="venue" name="venue" maxlength="80" value="<c:out value='${event.venue}'/>" required>

    <div class="form-row">
      <div><label for="eventDate">Date</label><input type="date" id="eventDate" name="eventDate" value="${event.eventDate}" required></div>
      <div><label for="totalSeats">Total seats</label><input type="number" id="totalSeats" name="totalSeats" min="1" value="${event.totalSeats}" required></div>
    </div>

    <button type="submit" class="btn btn-primary">Save event</button>
  </form>
  <p class="form-foot"><a href="${ctx}/events">Cancel and go back</a></p>
</div>

<%@ include file="/WEB-INF/views/includes/footer.jsp" %>
