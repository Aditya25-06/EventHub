<%-- JSP declaration: a method added to the generated servlet class --%>
<%!
    private String currentYear() {
        return String.valueOf(java.time.Year.now().getValue());
    }
%>
<%-- JSP scriptlet: visitor counter kept in the "application" implicit object (one count per session) --%>
<%
    int visitorCount;
    synchronized (application) {
        Integer stored = (Integer) application.getAttribute("hits");
        visitorCount = (stored == null) ? 0 : stored;
        if (session.getAttribute("counted") == null) {
            visitorCount++;
            application.setAttribute("hits", visitorCount);
            session.setAttribute("counted", Boolean.TRUE);
        }
    }
%>
</main>
<footer class="footer">
  &copy; <%= currentYear() %> EventHub &nbsp;|&nbsp; Visitors so far: <%= visitorCount %>
  &nbsp;|&nbsp; Help: <c:out value="${applicationScope.adminEmail}"/>
</footer>
</body>
</html>
