<%-- Shared header, pulled in with the JSP include DIRECTIVE (static include). --%>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><c:out value="${pageTitle}"/> | EventHub</title>
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="${ctx}/css/style.css">
</head>
<body>
<nav class="navbar">
  <a class="brand" href="${ctx}/dashboard">Event<span>Hub</span></a>
  <div class="nav-links">
    <c:choose>
      <c:when test="${not empty sessionScope.user}">
        <a href="${ctx}/dashboard">Dashboard</a>
        <a href="${ctx}/events">Events</a>
        <c:if test="${sessionScope.user.role == 'STUDENT'}"><a href="${ctx}/my-registrations">My registrations</a></c:if>
        <c:if test="${sessionScope.user.role == 'ADMIN'}">
          <a href="${ctx}/admin/event?action=new">Add event</a>
          <a href="${ctx}/admin/report">Participants</a>
        </c:if>
        <span class="user-chip"><c:out value="${sessionScope.user.name}"/></span>
        <a class="nav-cta" href="${ctx}/logout">Log out</a>
      </c:when>
      <c:otherwise>
        <a href="${ctx}/login">Log in</a>
        <a class="nav-cta" href="${ctx}/signup">Sign up</a>
      </c:otherwise>
    </c:choose>
  </div>
</nav>
<main class="container">
<c:choose>
  <c:when test="${param.msg == 'signedup'}"><div class="alert alert-ok">Account created. Log in to see upcoming events.</div></c:when>
  <c:when test="${param.msg == 'loggedout'}"><div class="alert alert-info">You have been logged out.</div></c:when>
  <c:when test="${param.msg == 'loginfirst'}"><div class="alert alert-info">Log in to open that page.</div></c:when>
  <c:when test="${param.msg == 'denied'}"><div class="alert alert-err">That page is for admins only.</div></c:when>
  <c:when test="${param.msg == 'registered'}"><div class="alert alert-ok">You are registered. See you there!</div></c:when>
  <c:when test="${param.msg == 'dup'}"><div class="alert alert-info">You are already registered for that event.</div></c:when>
  <c:when test="${param.msg == 'full'}"><div class="alert alert-err">That event is full. Try another one.</div></c:when>
  <c:when test="${param.msg == 'cancelled'}"><div class="alert alert-ok">Registration cancelled. Your seat is free again.</div></c:when>
  <c:when test="${param.msg == 'saved'}"><div class="alert alert-ok">Event saved.</div></c:when>
  <c:when test="${param.msg == 'deleted'}"><div class="alert alert-ok">Event deleted.</div></c:when>
  <c:when test="${param.msg == 'error'}"><div class="alert alert-err">Something went wrong. Check your input and try again.</div></c:when>
</c:choose>
