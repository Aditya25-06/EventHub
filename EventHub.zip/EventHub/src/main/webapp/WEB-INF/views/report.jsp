<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Participants" scope="request"/>
<%@ include file="/WEB-INF/views/includes/header.jsp" %>

<h1 class="page-title">Participants</h1>
<p class="page-sub">Who registered for which event. Column names are read from ResultSetMetaData.</p>

<form method="get" action="${ctx}/admin/report" class="filter-bar">
  <select name="eventId" aria-label="Filter by event">
    <option value="0">All events</option>
    <c:forEach var="e" items="${events}">
      <option value="${e.eventId}" ${e.eventId == selectedEvent ? 'selected' : ''}><c:out value="${e.title}"/></option>
    </c:forEach>
  </select>
  <button type="submit" class="btn btn-primary btn-sm">Show</button>
</form>

<c:choose>
  <c:when test="${empty rows}">
    <div class="empty">No registrations found for this selection.</div>
  </c:when>
  <c:otherwise>
    <div class="table-wrap">
      <table>
        <thead>
          <tr><c:forEach var="h" items="${headers}"><th><c:out value="${h}"/></th></c:forEach></tr>
        </thead>
        <tbody>
          <c:forEach var="row" items="${rows}">
            <tr><c:forEach var="cell" items="${row}"><td><c:out value="${cell}"/></td></c:forEach></tr>
          </c:forEach>
        </tbody>
      </table>
    </div>
  </c:otherwise>
</c:choose>

<%@ include file="/WEB-INF/views/includes/footer.jsp" %>
