-- EventHub database script (MySQL 8.0)
CREATE DATABASE IF NOT EXISTS eventhub_db;
USE eventhub_db;

DROP TABLE IF EXISTS registrations;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    user_id  INT AUTO_INCREMENT PRIMARY KEY,
    name     VARCHAR(60)  NOT NULL,
    email    VARCHAR(80)  NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,           -- SHA-256 hash
    role     VARCHAR(10)  NOT NULL DEFAULT 'STUDENT'
);

CREATE TABLE events (
    event_id        INT AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(100) NOT NULL,
    description     TEXT,
    venue           VARCHAR(80),
    event_date      DATE,
    total_seats     INT NOT NULL,
    available_seats INT NOT NULL
);

CREATE TABLE registrations (
    reg_id   INT AUTO_INCREMENT PRIMARY KEY,
    user_id  INT NOT NULL,
    event_id INT NOT NULL,
    reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_user_event (user_id, event_id),
    FOREIGN KEY (user_id)  REFERENCES users(user_id)   ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE
);

-- Demo logins:  admin@eventhub.com / admin123   |   student@eventhub.com / student123
INSERT INTO users (name, email, password, role) VALUES
('Administrator', 'admin@eventhub.com',   SHA2('admin123', 256),   'ADMIN'),
('Demo Student',  'student@eventhub.com', SHA2('student123', 256), 'STUDENT');

INSERT INTO events (title, description, venue, event_date, total_seats, available_seats) VALUES
('Hack the Campus 24H', 'A 24-hour coding marathon. Build, break and ship with your team.', 'Computer Lab 3', DATE_ADD(CURDATE(), INTERVAL 10 DAY), 60, 60),
('Cloud & DevOps Workshop', 'Hands-on session on deployment, containers and CI/CD pipelines.', 'Seminar Hall A', DATE_ADD(CURDATE(), INTERVAL 15 DAY), 40, 40),
('Annual Cultural Fest', 'Music, dance, drama and food stalls. Bring your friends!', 'Main Auditorium', DATE_ADD(CURDATE(), INTERVAL 25 DAY), 300, 300),
('Inter-College Cricket Cup', 'Knock-out tournament with teams from five colleges.', 'College Ground', DATE_ADD(CURDATE(), INTERVAL 30 DAY), 120, 120),
('Resume & Interview Clinic', 'Get your resume reviewed and attend a mock interview round.', 'Placement Cell', DATE_ADD(CURDATE(), INTERVAL 12 DAY), 25, 25),
('AI for Everyone Seminar', 'Guest lecture on practical uses of AI in daily life and careers.', 'Seminar Hall B', DATE_ADD(CURDATE(), INTERVAL 20 DAY), 80, 80);
